import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

import 'api_exceptions.dart';
import 'config.dart';
import 'session.dart';

/// Учебные переключатели сервера (`__delay`, `__fail`), переданные в адресе
/// страницы, добавляются к каждому запросу: так проверяются индикатор
/// загрузки и состояние ошибки без правки кода.
Map<String, String> _debugSwitches() {
  if (!kIsWeb) return const {};
  final p = Uri.base.queryParameters;
  return {
    for (final k in const ['__delay', '__fail'])
      if (p[k] != null) k: p[k]!,
  };
}

Dio buildDio(
  ApiSession session, {
  String baseUrl = apiBaseUrl,
  Duration retryDelay = const Duration(milliseconds: 400),
}) {
  final dio = Dio(
    BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 15),
      headers: {'Content-Type': 'application/json'},
      // Коды 4xx не бросают исключение — их разбирает интерсептор.
      validateStatus: (status) => status != null && status < 500,
    ),
  );
  dio.interceptors.add(ApiInterceptor(dio, session, retryDelay: retryDelay));
  return dio;
}

/// Общая обработка запросов: токен, журнал, разбор ошибок, повтор чтения
/// при сетевом сбое и повторный вход при истёкшем токене.
class ApiInterceptor extends Interceptor {
  ApiInterceptor(this._dio, this._session,
      {this.retryDelay = const Duration(milliseconds: 400)});

  final Dio _dio;
  final ApiSession _session;
  final Duration retryDelay;

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    options.queryParameters = {...options.queryParameters, ..._debugSwitches()};
    final token = _session.token;
    if (token != null && options.extra['skipAuth'] != true) {
      options.headers['Authorization'] = 'Bearer $token';
    }
    options.extra['startedAt'] ??= DateTime.now().millisecondsSinceEpoch;
    handler.next(options);
  }

  @override
  Future<void> onResponse(
      Response<dynamic> response, ResponseInterceptorHandler handler) async {
    _log(response.requestOptions, response.statusCode);
    final status = response.statusCode ?? 0;
    if (status < 400) {
      handler.next(response);
      return;
    }

    final options = response.requestOptions;
    // Токен истёк — входим заново и повторяем запрос один раз.
    if (status == 401 &&
        options.extra['skipAuth'] != true &&
        options.extra['reauth'] != true &&
        await _session.login(_dio)) {
      options.extra['reauth'] = true;
      try {
        handler.resolve(await _dio.fetch<dynamic>(options));
      } on DioException catch (e) {
        handler.reject(e, true);
      }
      return;
    }
    // throw здесь нельзя: Dio завернёт исключение в DioException(unknown).
    handler.reject(
      DioException(
        requestOptions: options,
        response: response,
        type: DioExceptionType.badResponse,
        error: mapHttpError(status, response.data),
      ),
      true,
    );
  }

  @override
  Future<void> onError(
      DioException err, ErrorInterceptorHandler handler) async {
    final options = err.requestOptions;
    if (err.error is! ApiException) {
      _log(options, err.response?.statusCode, failure: err.type.name);
    }
    if (_isRetryable(err)) {
      final attempt = (options.extra['attempt'] as int? ?? 1);
      if (attempt < maxReadAttempts) {
        // Нарастающая пауза: 400, 800 мс…
        await Future<void>.delayed(retryDelay * (1 << (attempt - 1)));
        options.extra['attempt'] = attempt + 1;
        if (kDebugMode) {
          debugPrint('[API] повтор ${attempt + 1}/$maxReadAttempts '
              '${options.method} ${options.uri}');
        }
        try {
          handler.resolve(await _dio.fetch<dynamic>(options));
        } on DioException catch (e) {
          handler.next(e);
        }
        return;
      }
    }
    handler.next(err);
  }

  /// Повторяется только чтение и только при сетевом сбое: повтор создания
  /// записи мог бы создать её дважды.
  bool _isRetryable(DioException e) {
    if (e.requestOptions.method.toUpperCase() != 'GET') return false;
    if (e.requestOptions.cancelToken?.isCancelled ?? false) return false;
    return switch (e.type) {
      DioExceptionType.connectionError ||
      DioExceptionType.connectionTimeout ||
      DioExceptionType.receiveTimeout =>
        true,
      _ => false,
    };
  }

  void _log(RequestOptions options, int? status, {String? failure}) {
    if (!kDebugMode) return;
    final started = options.extra['startedAt'] as int?;
    final ms = started == null
        ? ''
        : ' ${DateTime.now().millisecondsSinceEpoch - started} мс';
    debugPrint('[API] ${options.method} ${options.uri} → '
        '${status ?? failure ?? '—'}$ms');
  }
}
