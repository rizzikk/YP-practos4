/// Параметры сборки. Адрес сервера не зашит в код: он передаётся ключом
/// `--dart-define=API_BASE_URL=...` (на занятии, дома и при публикации разный).
library;

const apiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://localhost:8080/api',
);

/// Служебная учётная запись: вход в интерфейсе появится в ПР5, а запись
/// и удаление на учебном сервере требуют роли librarian/admin.
const apiUser = String.fromEnvironment('API_USER', defaultValue: 'admin');
const apiPassword =
    String.fromEnvironment('API_PASSWORD', defaultValue: 'admin123');

/// Сколько раз повторять чтение при сетевом сбое.
const maxReadAttempts = 3;
