import 'package:dio/dio.dart';

import 'config.dart';

/// Токен доступа служебной учётной записи. Экран входа — в ПР5;
/// пока приложение входит само, чтобы работали запись и удаление.
class ApiSession {
  String? _token;
  Future<bool>? _pending;

  String? get token => _token;

  /// Вход. Одновременные вызовы объединяются в один запрос.
  Future<bool> login(Dio dio) => _pending ??= _login(dio).whenComplete(() {
        _pending = null;
      });

  Future<bool> _login(Dio dio) async {
    try {
      final response = await dio.post<dynamic>(
        '/auth/login',
        data: {'username': apiUser, 'password': apiPassword},
        options: Options(extra: {'skipAuth': true}),
      );
      final data = response.data;
      _token = data is Map ? data['accessToken'] as String? : null;
      return _token != null;
    } on DioException {
      _token = null;
      return false;
    }
  }
}
