import 'package:flutter/material.dart';
import 'package:flutter_web_plugins/url_strategy.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'core/api_client.dart';
import 'core/session.dart';
import 'repositories/api_repositories.dart';
import 'repositories/author_repository.dart';
import 'repositories/book_repository.dart';
import 'repositories/reader_repository.dart';
import 'repositories/reference_repository.dart';
import 'state/author_list_notifier.dart';
import 'state/book_list_notifier.dart';
import 'state/catalog_notifier.dart';
import 'state/form_guard.dart';
import 'state/list_notifiers.dart';
import 'state/loan_notifier.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Адреса без «#»: /books?page=2 вместо /#/books?page=2.
  usePathUrlStrategy();

  // Сетевой слой. Адрес сервера — параметр сборки (--dart-define=API_BASE_URL).
  final session = ApiSession();
  final dio = buildDio(session);
  // Вход служебной учётной записью (экран входа — в ПР5). Если сервер
  // недоступен, приложение всё равно запускается и покажет ошибку в списке.
  await session.login(dio);

  // Единственное место, где сменилась реализация: было Stored…Repository
  // (localStorage), стало Api…Repository. Экраны и состояние те же.
  final books = ApiBookRepository(dio);
  final authors = ApiAuthorRepository(dio);
  final genres = ApiGenreRepository(dio);
  final publishers = ApiPublisherRepository(dio);
  final readers = ApiReaderRepository(dio);
  final loans = ApiLoanRepository(dio);

  runApp(
    MultiProvider(
      providers: [
        Provider<BookRepository>.value(value: books),
        Provider<AuthorRepository>.value(value: authors),
        Provider<GenreRepository>.value(value: genres),
        Provider<PublisherRepository>.value(value: publishers),
        Provider<ReaderRepository>.value(value: readers),
        Provider<LoanNotifier>(create: (_) => LoanNotifier(loans, readers)),
        Provider<UnsavedChangesGuard>(create: (_) => UnsavedChangesGuard()),
        // Справочники загружаются один раз и кэшируются; перечитываются
        // только после изменения авторов, жанров или издательств.
        ChangeNotifierProvider(
          create: (_) => CatalogNotifier(genres, publishers, authors)..load(),
        ),
        ChangeNotifierProvider(create: (_) => BookListNotifier(books)),
        ChangeNotifierProvider(
          create: (context) => AuthorListNotifier(authors,
              onChanged: context.read<CatalogNotifier>().load),
        ),
        ChangeNotifierProvider(
          create: (context) => GenreListNotifier(genres,
              onChanged: context.read<CatalogNotifier>().load),
        ),
        ChangeNotifierProvider(
          create: (context) => PublisherListNotifier(publishers, books,
              onChanged: context.read<CatalogNotifier>().load),
        ),
        ChangeNotifierProvider(create: (_) => ReaderListNotifier(readers)),
      ],
      child: const LibraryApp(),
    ),
  );
}
