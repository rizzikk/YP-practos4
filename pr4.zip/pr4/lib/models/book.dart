import 'json_utils.dart';

/// Книга. Неизменяемая модель: любое изменение — через [copyWith].
class Book {
  final int id;
  final String title;
  final String isbn;
  final int year;
  final int pages;
  final int publisherId;
  final List<int> authorIds;
  final List<int> genreIds;
  final int copiesTotal;
  final int copiesAvailable;
  final DateTime? deletedAt;

  const Book({
    required this.id,
    required this.title,
    required this.isbn,
    required this.year,
    required this.pages,
    required this.publisherId,
    required this.authorIds,
    required this.genreIds,
    required this.copiesTotal,
    required this.copiesAvailable,
    this.deletedAt,
  });

  bool get isDeleted => deletedAt != null;

  /// [clearDeletedAt] нужен, чтобы отличить «не менять поле» от «записать null»:
  /// без него оба случая выглядят как переданный `null`.
  Book copyWith({
    String? title,
    String? isbn,
    int? year,
    int? pages,
    int? publisherId,
    List<int>? authorIds,
    List<int>? genreIds,
    int? copiesTotal,
    int? copiesAvailable,
    DateTime? deletedAt,
    bool clearDeletedAt = false,
  }) {
    return Book(
      id: id,
      title: title ?? this.title,
      isbn: isbn ?? this.isbn,
      year: year ?? this.year,
      pages: pages ?? this.pages,
      publisherId: publisherId ?? this.publisherId,
      authorIds: authorIds ?? this.authorIds,
      genreIds: genreIds ?? this.genreIds,
      copiesTotal: copiesTotal ?? this.copiesTotal,
      copiesAvailable: copiesAvailable ?? this.copiesAvailable,
      deletedAt: clearDeletedAt ? null : (deletedAt ?? this.deletedAt),
    );
  }

  /// Копия с новым идентификатором — используется репозиторием при создании.
  Book withId(int newId) => Book(
        id: newId,
        title: title,
        isbn: isbn,
        year: year,
        pages: pages,
        publisherId: publisherId,
        authorIds: authorIds,
        genreIds: genreIds,
        copiesTotal: copiesTotal,
        copiesAvailable: copiesAvailable,
        deletedAt: deletedAt,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'isbn': isbn,
        'year': year,
        'pages': pages,
        'publisherId': publisherId,
        'authorIds': authorIds,
        'genreIds': genreIds,
        'copiesTotal': copiesTotal,
        'copiesAvailable': copiesAvailable,
        'deletedAt': deletedAt?.toIso8601String(),
      };

  /// Представление для записи (POST/PUT): связи передаются идентификаторами,
  /// число доступных экземпляров сервер считает сам.
  Map<String, dynamic> toInput() => {
        'title': title,
        'isbn': isbn,
        'year': year,
        'pages': pages,
        'publisherId': publisherId,
        'authorIds': authorIds,
        'genreIds': genreIds,
        'copiesTotal': copiesTotal,
      };

  /// Разбор устойчив к отсутствующим полям, `null` и другим типам и понимает
  /// обе формы связей: `publisherId`/`authorIds` (запись) и развёрнутые
  /// объекты `publisher`/`authors`/`genres` (ответ сервера).
  factory Book.fromJson(Map<String, dynamic> json) => Book(
        id: readInt(json['id']),
        title: readString(json['title']),
        isbn: readString(json['isbn']),
        year: readInt(json['year']),
        pages: readInt(json['pages']),
        publisherId:
            readRefId(json['publisher']) ?? readInt(json['publisherId']),
        authorIds: json['authors'] is List
            ? readRefIds(json['authors'])
            : readIntList(json['authorIds']),
        genreIds: json['genres'] is List
            ? readRefIds(json['genres'])
            : readIntList(json['genreIds']),
        copiesTotal: readInt(json['copiesTotal']),
        copiesAvailable: readInt(json['copiesAvailable']),
        deletedAt: readDate(json['deletedAt']),
      );}
