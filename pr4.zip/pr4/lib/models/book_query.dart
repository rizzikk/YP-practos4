import 'query_params.dart';

/// Все условия отбора списка книг в одном неизменяемом объекте.
class BookQuery {
  static const Set<String> sortFields = {'title', 'year', 'pages', 'available'};
  static const String defaultSortField = 'title';

  final String search;
  final int? genreId;
  final int? publisherId;
  final int? yearFrom;
  final int? yearTo;
  final String sortField;
  final bool sortAscending;
  final int page;
  final int size;
  final bool includeDeleted;

  const BookQuery({
    this.search = '',
    this.genreId,
    this.publisherId,
    this.yearFrom,
    this.yearTo,
    this.sortField = defaultSortField,
    this.sortAscending = true,
    this.page = 1,
    this.size = defaultPageSize,
    this.includeDeleted = false,
  });

  /// Восстановление условий из адреса `/books?search=…&genreId=2&sort=year,desc&page=3`.
  factory BookQuery.fromQueryParameters(Map<String, String> p) {
    final sort =
        parseSort(p['sort'], allowed: sortFields, fallback: defaultSortField);
    return BookQuery(
      search: (p['search'] ?? '').trim(),
      genreId: parseIntParam(p['genreId']),
      publisherId: parseIntParam(p['publisherId']),
      yearFrom: parseIntParam(p['yearFrom']),
      yearTo: parseIntParam(p['yearTo']),
      sortField: sort.field,
      sortAscending: sort.ascending,
      page: parsePage(p['page']),
      size: parseSize(p['size']),
      includeDeleted: parseBoolParam(p['deleted']),
    );
  }

  /// В адрес попадают только значения, отличные от значений по умолчанию.
  Map<String, String> toQueryParameters() => {
        if (search.isNotEmpty) 'search': search,
        if (genreId != null) 'genreId': '$genreId',
        if (publisherId != null) 'publisherId': '$publisherId',
        if (yearFrom != null) 'yearFrom': '$yearFrom',
        if (yearTo != null) 'yearTo': '$yearTo',
        if (sortField != defaultSortField || !sortAscending)
          'sort': formatSort(sortField, sortAscending),
        if (page != 1) 'page': '$page',
        if (size != defaultPageSize) 'size': '$size',
        if (includeDeleted) 'deleted': '1',
      };

  bool get hasFilters =>
      search.isNotEmpty ||
      genreId != null ||
      publisherId != null ||
      yearFrom != null ||
      yearTo != null ||
      includeDeleted;

  /// Число активных фильтров без учёта поиска — для значка на кнопке «Фильтры».
  int get activeFilterCount => [
        genreId != null,
        publisherId != null,
        yearFrom != null,
        yearTo != null,
        includeDeleted,
      ].where((x) => x).length;

  /// Сброс фильтров с сохранением сортировки и размера страницы.
  BookQuery clearFilters() => BookQuery(
        sortField: sortField,
        sortAscending: sortAscending,
        size: size,
      );

  BookQuery copyWith({
    String? search,
    Object? genreId = _unset,
    Object? publisherId = _unset,
    Object? yearFrom = _unset,
    Object? yearTo = _unset,
    String? sortField,
    bool? sortAscending,
    int? page,
    int? size,
    bool? includeDeleted,
  }) {
    return BookQuery(
      search: search ?? this.search,
      genreId: genreId == _unset ? this.genreId : genreId as int?,
      publisherId:
          publisherId == _unset ? this.publisherId : publisherId as int?,
      yearFrom: yearFrom == _unset ? this.yearFrom : yearFrom as int?,
      yearTo: yearTo == _unset ? this.yearTo : yearTo as int?,
      sortField: sortField ?? this.sortField,
      sortAscending: sortAscending ?? this.sortAscending,
      // Любое изменение условий отбора возвращает на первую страницу
      page: page ?? 1,
      size: size ?? this.size,
      includeDeleted: includeDeleted ?? this.includeDeleted,
    );
  }

  /// Позволяет отличить «параметр не передан» от «передан null — сбросить фильтр».
  static const _unset = Object();

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BookQuery &&
          search == other.search &&
          genreId == other.genreId &&
          publisherId == other.publisherId &&
          yearFrom == other.yearFrom &&
          yearTo == other.yearTo &&
          sortField == other.sortField &&
          sortAscending == other.sortAscending &&
          page == other.page &&
          size == other.size &&
          includeDeleted == other.includeDeleted;

  @override
  int get hashCode => Object.hash(search, genreId, publisherId, yearFrom,
      yearTo, sortField, sortAscending, page, size, includeDeleted);
}
