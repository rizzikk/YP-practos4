/// Безопасный разбор значений из JSON.
///
/// Данные из хранилища (а в ПР4 — из ответа сервера) могут прийти без поля,
/// с `null` или с другим типом. Поэтому ни одно значение не приводится
/// через `as int` без запасного варианта.
library;

int readInt(Object? value, [int fallback = 0]) => readIntOrNull(value) ?? fallback;

int? readIntOrNull(Object? value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.tryParse(value.trim());
  return null;
}

String readString(Object? value, [String fallback = '']) =>
    readStringOrNull(value) ?? fallback;

String? readStringOrNull(Object? value) {
  if (value == null) return null;
  return value is String ? value : value.toString();
}

bool readBool(Object? value, [bool fallback = false]) {
  if (value is bool) return value;
  if (value is num) return value != 0;
  if (value is String) return value == 'true' || value == '1';
  return fallback;
}

List<int> readIntList(Object? value) => value is List
    ? value.map(readIntOrNull).whereType<int>().toList()
    : const <int>[];

DateTime? readDate(Object? value) =>
    value is String ? DateTime.tryParse(value) : null;

Map<String, dynamic> readMap(Object? value) =>
    value is Map ? Map<String, dynamic>.from(value) : const <String, dynamic>{};

/// Идентификатор связанной записи: сервер присылает развёрнутый объект
/// `{"id": 1, "name": "АСТ"}`, а при записи ждёт просто `1`.
int? readRefId(Object? value) =>
    value is Map ? readIntOrNull(value['id']) : readIntOrNull(value);

/// Список идентификаторов из `[1, 2]` или `[{"id": 1}, {"id": 2}]`.
List<int> readRefIds(Object? value) => value is List
    ? value.map(readRefId).whereType<int>().toList()
    : const <int>[];
