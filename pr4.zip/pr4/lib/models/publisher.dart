import 'json_utils.dart';

/// Издательство. Поля соответствуют контракту учебного API.
class Publisher {
  final int id;
  final String name;
  final String city;
  final int? foundedYear;
  final DateTime? deletedAt;

  const Publisher({
    required this.id,
    required this.name,
    this.city = '',
    this.foundedYear,
    this.deletedAt,
  });

  bool get isDeleted => deletedAt != null;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'city': city,
        'foundedYear': foundedYear,
        'deletedAt': deletedAt?.toIso8601String(),
      };

  Map<String, dynamic> toInput() =>
      {'name': name, 'city': city, 'foundedYear': foundedYear};

  factory Publisher.fromJson(Map<String, dynamic> json) => Publisher(
        id: readInt(json['id']),
        name: readString(json['name']),
        city: readString(json['city']),
        foundedYear: readIntOrNull(json['foundedYear']),
        deletedAt: readDate(json['deletedAt']),
      );
}
