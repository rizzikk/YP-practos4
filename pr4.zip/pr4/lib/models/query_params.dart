/// Разбор и формирование параметров адреса, общие для всех списков.
library;

/// Допустимые размеры страницы (п. 13 задания).
const List<int> allowedPageSizes = [10, 25, 50];
const int defaultPageSize = 10;

int? parseIntParam(String? value) => value == null ? null : int.tryParse(value);

int parsePage(String? value) {
  final page = parseIntParam(value);
  return page == null || page < 1 ? 1 : page;
}

int parseSize(String? value) {
  final size = parseIntParam(value);
  return size != null && allowedPageSizes.contains(size) ? size : defaultPageSize;
}

bool parseBoolParam(String? value) => value == '1' || value == 'true';

/// `year,desc` → (field: 'year', ascending: false). Неизвестное поле
/// заменяется значением по умолчанию: адрес может прийти откуда угодно.
({String field, bool ascending}) parseSort(
  String? value, {
  required Set<String> allowed,
  required String fallback,
}) {
  if (value == null || value.isEmpty) return (field: fallback, ascending: true);
  final parts = value.split(',');
  final field = allowed.contains(parts.first) ? parts.first : fallback;
  final ascending = parts.length < 2 || parts[1] != 'desc';
  return (field: field, ascending: ascending);
}

String formatSort(String field, bool ascending) =>
    ascending ? field : '$field,desc';
