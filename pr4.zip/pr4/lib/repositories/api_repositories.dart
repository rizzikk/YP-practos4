import 'package:dio/dio.dart';

import '../core/api_exceptions.dart';
import '../models/author.dart';
import '../models/author_query.dart';
import '../models/book.dart';
import '../models/book_query.dart';
import '../models/genre.dart';
import '../models/list_query.dart';
import '../models/loan.dart';
import '../models/publisher.dart';
import '../models/reader.dart';
import 'api_repository.dart';
import 'author_repository.dart';
import 'book_repository.dart';
import 'loan_repository.dart';
import 'reader_repository.dart';
import 'reference_repository.dart';

/// Имена полей сортировки в интерфейсе → имена полей на сервере.
const _bookSortFields = {'available': 'copiesAvailable'};

class ApiBookRepository extends ApiCrudRepository<Book, BookQuery>
    implements BookRepository {
  ApiBookRepository(Dio dio) : super(dio, '/books');

  @override
  Book fromJson(Map<String, dynamic> json) => Book.fromJson(json);
  @override
  Map<String, dynamic> toInput(Book entity) => entity.toInput();
  @override
  int idOf(Book entity) => entity.id;

  @override
  Map<String, dynamic> queryParams(BookQuery q) => {
        if (q.search.trim().isNotEmpty) 'search': q.search.trim(),
        if (q.genreId != null) 'genreId': q.genreId,
        if (q.publisherId != null) 'publisherId': q.publisherId,
        if (q.yearFrom != null) 'yearFrom': q.yearFrom,
        if (q.yearTo != null) 'yearTo': q.yearTo,
        'sort': apiSort(_bookSortFields[q.sortField] ?? q.sortField, q.sortAscending),
        'page': q.page,
        'size': q.size,
        if (q.includeDeleted) 'includeDeleted': true,
      };

  @override
  Future<List<Book>> findByAuthor(int authorId) =>
      fetchAll({'authorId': authorId, 'includeDeleted': true, 'sort': 'year,asc'});

  @override
  Future<List<Book>> findByGenre(int genreId) =>
      fetchAll({'genreId': genreId, 'includeDeleted': true, 'sort': 'year,asc'});

  @override
  Future<List<Book>> findByPublisher(int publisherId) => fetchAll(
      {'publisherId': publisherId, 'includeDeleted': true, 'sort': 'year,asc'});

  @override
  Future<int> countByPublisher(int publisherId) => guard(() async {
        final response = await dio.get<dynamic>(path, queryParameters: {
          'publisherId': publisherId,
          'includeDeleted': true,
          'size': 1,
        });
        return parsePage(response.data).total;
      });
}

class ApiAuthorRepository extends ApiCrudRepository<Author, AuthorQuery>
    implements AuthorRepository {
  ApiAuthorRepository(Dio dio) : super(dio, '/authors');

  @override
  Author fromJson(Map<String, dynamic> json) => Author.fromJson(json);
  @override
  Map<String, dynamic> toInput(Author entity) => entity.toInput();
  @override
  int idOf(Author entity) => entity.id;

  @override
  Map<String, dynamic> queryParams(AuthorQuery q) => {
        if (q.search.trim().isNotEmpty) 'search': q.search.trim(),
        'sort': apiSort(q.sortField, q.sortAscending),
        'page': q.page,
        'size': q.size,
        if (q.includeDeleted) 'includeDeleted': true,
      };
}

/// Параметры для простых списков (жанры, издательства, читатели).
Map<String, dynamic> _listParams(ListQuery q) => {
      if (q.search.trim().isNotEmpty) 'search': q.search.trim(),
      'sort': apiSort(q.sortField, q.sortAscending),
      'page': q.page,
      'size': q.size,
      if (q.includeDeleted) 'includeDeleted': true,
    };

class ApiGenreRepository extends ApiCrudRepository<Genre, ListQuery>
    implements GenreRepository {
  ApiGenreRepository(Dio dio) : super(dio, '/genres');

  @override
  Genre fromJson(Map<String, dynamic> json) => Genre.fromJson(json);
  @override
  Map<String, dynamic> toInput(Genre entity) => entity.toInput();
  @override
  int idOf(Genre entity) => entity.id;
  @override
  Map<String, dynamic> queryParams(ListQuery q) => _listParams(q);
}

class ApiPublisherRepository extends ApiCrudRepository<Publisher, ListQuery>
    implements PublisherRepository {
  ApiPublisherRepository(Dio dio) : super(dio, '/publishers');

  @override
  Publisher fromJson(Map<String, dynamic> json) => Publisher.fromJson(json);
  @override
  Map<String, dynamic> toInput(Publisher entity) => entity.toInput();
  @override
  int idOf(Publisher entity) => entity.id;
  @override
  Map<String, dynamic> queryParams(ListQuery q) => _listParams(q);
}

class ApiReaderRepository extends ApiCrudRepository<Reader, ListQuery>
    implements ReaderRepository {
  ApiReaderRepository(Dio dio) : super(dio, '/readers');

  @override
  Reader fromJson(Map<String, dynamic> json) => Reader.fromJson(json);
  @override
  Map<String, dynamic> toInput(Reader entity) => entity.toInput();
  @override
  int idOf(Reader entity) => entity.id;
  @override
  Map<String, dynamic> queryParams(ListQuery q) => _listParams(q);
}

class ApiLoanRepository implements LoanRepository {
  ApiLoanRepository(this._dio);
  final Dio _dio;

  @override
  Future<Loan> issue({required int readerId, required int bookId, int days = 14}) =>
      guard(() async {
        final response = await _dio.post<dynamic>('/loans',
            data: {'readerId': readerId, 'bookId': bookId, 'days': days});
        return Loan.fromJson(Map<String, dynamic>.from(response.data as Map));
      });
}
