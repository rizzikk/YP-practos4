import '../models/loan.dart';

/// Выдачи книг. Пока нужна одна операция — оформить выдачу.
abstract interface class LoanRepository {
  /// Оформить выдачу. Нет свободных экземпляров — [ConflictException] (409).
  Future<Loan> issue({required int readerId, required int bookId, int days});
}
