import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../forms/entity_form.dart';
import '../models/author.dart';
import '../models/author_details.dart';
import '../models/author_query.dart';
import '../models/book.dart';
import '../models/book_query.dart';
import '../models/genre.dart';
import '../models/publisher.dart';
import '../models/reader.dart';
import '../repositories/author_repository.dart';
import '../repositories/book_repository.dart';
import '../repositories/reader_repository.dart';
import '../repositories/reference_repository.dart';
import '../screens/app_shell.dart';
import '../screens/author_details_screen.dart';
import '../screens/author_form_screen.dart';
import '../screens/authors_list_screen.dart';
import '../screens/book_details_screen.dart';
import '../screens/book_form_screen.dart';
import '../screens/books_list_screen.dart';
import '../screens/genre_screens.dart';
import '../screens/not_found_screen.dart';
import '../screens/publisher_screens.dart';
import '../screens/reader_screens.dart';
import '../state/details_notifier.dart';
import '../state/form_guard.dart';
import '../state/list_notifiers.dart';
import 'locations.dart';

/// Создаёт функцию загрузки записи. Репозитории берутся из провайдеров
/// здесь, в точке сборки; экраны к репозиториям не обращаются.
typedef LoaderFactory<T> = Future<T?> Function() Function(
    BuildContext context, int id);

/// Уход с экрана формы: при несохранённых изменениях — вопрос.
/// Срабатывает и при переходе по меню, и при кнопке «назад» браузера.
Future<bool> _confirmExit(BuildContext context, GoRouterState state) async {
  final guard = context.read<UnsavedChangesGuard>();
  if (!guard.dirty) return true;
  final leave = await confirmLeave(context);
  if (leave) guard.dirty = false;
  return leave;
}

Widget _withLoader<T>(
  GoRouterState state,
  LoaderFactory<T> loader,
  Widget Function(int id) screen,
) {
  final id = int.tryParse(state.pathParameters['id'] ?? '');
  if (id == null) return NotFoundScreen(location: state.uri.toString());
  return ChangeNotifierProvider(
    key: ValueKey(state.uri.path),
    create: (context) => DetailsNotifier<T>(loader(context, id))..load(),
    child: screen(id),
  );
}

GoRoute _list(String path, Widget Function(Map<String, String> params) screen) =>
    GoRoute(
      path: path,
      // Постоянный ключ страницы: при смене параметров экран обновляется,
      // а не пересоздаётся — поле поиска не теряет фокус.
      pageBuilder: (context, state) => NoTransitionPage(
        key: ValueKey('$path-list'),
        child: screen(state.uri.queryParameters),
      ),
    );

/// Маршрут /new должен стоять раньше /:id, иначе «new» примется за id.
GoRoute _create(String path, Widget form) => GoRoute(
      path: newLocation(path),
      onExit: _confirmExit,
      builder: (context, state) => form,
    );

GoRoute _details<D>(String path, LoaderFactory<D> loader, Widget Function(int id) screen) =>
    GoRoute(
      path: '$path/:id',
      builder: (context, state) => _withLoader<D>(state, loader, screen),
    );

GoRoute _edit<T>(String path, LoaderFactory<T> loader, Widget Function(int id) form) =>
    GoRoute(
      path: '$path/:id/edit',
      onExit: _confirmExit,
      builder: (context, state) => _withLoader<T>(state, loader, form),
    );

/// Маршруты приложения. Адрес — единственный источник условий отбора:
/// экран списка получает их из параметров адреса, а не хранит у себя.
GoRouter createRouter() => GoRouter(
      initialLocation: booksPath,
      errorBuilder: (context, state) =>
          NotFoundScreen(location: state.uri.toString()),
      routes: [
        GoRoute(path: '/', redirect: (context, state) => booksPath),
        ShellRoute(
          builder: (context, state, child) =>
              AppShell(location: state.uri.path, child: child),
          routes: [
            // ---------------------------------------------------- книги
            _list(booksPath,
                (p) => BooksListScreen(query: BookQuery.fromQueryParameters(p))),
            _create(booksPath, const BookFormScreen()),
            _details<Book>(booksPath, _bookLoader, (id) => BookDetailsScreen(id: id)),
            _edit<Book>(booksPath, _bookLoader, (id) => BookFormScreen(id: id)),
            // --------------------------------------------------- авторы
            _list(authorsPath,
                (p) => AuthorsListScreen(query: AuthorQuery.fromQueryParameters(p))),
            _create(authorsPath, const AuthorFormScreen()),
            _details<AuthorDetails>(authorsPath, (context, id) {
              final authors = context.read<AuthorRepository>();
              final books = context.read<BookRepository>();
              return () async {
                final author = await authors.findById(id);
                if (author == null) return null;
                return AuthorDetails(author: author, books: await books.findByAuthor(id));
              };
            }, (id) => AuthorDetailsScreen(id: id)),
            _edit<Author>(authorsPath, (context, id) {
              final authors = context.read<AuthorRepository>();
              return () => authors.findById(id);
            }, (id) => AuthorFormScreen(id: id)),
            // ---------------------------------------------------- жанры
            _list(genresPath,
                (p) => GenresListScreen(query: genreListSpec.parse(p))),
            _create(genresPath, const GenreFormScreen()),
            _details<GenreDetails>(genresPath, (context, id) {
              final genres = context.read<GenreRepository>();
              final books = context.read<BookRepository>();
              return () async {
                final genre = await genres.findById(id);
                if (genre == null) return null;
                return (genre: genre, books: await books.findByGenre(id));
              };
            }, (id) => GenreDetailsScreen(id: id)),
            _edit<Genre>(genresPath, (context, id) {
              final genres = context.read<GenreRepository>();
              return () => genres.findById(id);
            }, (id) => GenreFormScreen(id: id)),
            // --------------------------------------------- издательства
            _list(publishersPath,
                (p) => PublishersListScreen(query: publisherListSpec.parse(p))),
            _create(publishersPath, const PublisherFormScreen()),
            _details<PublisherDetails>(publishersPath, (context, id) {
              final publishers = context.read<PublisherRepository>();
              final books = context.read<BookRepository>();
              return () async {
                final publisher = await publishers.findById(id);
                if (publisher == null) return null;
                return (
                  publisher: publisher,
                  books: await books.findByPublisher(id),
                );
              };
            }, (id) => PublisherDetailsScreen(id: id)),
            _edit<Publisher>(publishersPath, (context, id) {
              final publishers = context.read<PublisherRepository>();
              return () => publishers.findById(id);
            }, (id) => PublisherFormScreen(id: id)),
            // ------------------------------------------------- читатели
            _list(readersPath,
                (p) => ReadersListScreen(query: readerListSpec.parse(p))),
            _create(readersPath, const ReaderFormScreen()),
            _details<Reader>(readersPath, _readerLoader, (id) => ReaderDetailsScreen(id: id)),
            _edit<Reader>(readersPath, _readerLoader, (id) => ReaderFormScreen(id: id)),
          ],
        ),
      ],
    );

Future<Book?> Function() _bookLoader(BuildContext context, int id) {
  final books = context.read<BookRepository>();
  return () => books.findById(id);
}

Future<Reader?> Function() _readerLoader(BuildContext context, int id) {
  final readers = context.read<ReaderRepository>();
  return () => readers.findById(id);
}
