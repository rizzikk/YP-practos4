import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../router/locations.dart';
import '../state/author_list_notifier.dart';
import '../state/book_list_notifier.dart';
import '../state/list_notifiers.dart';

/// Общая оболочка: боковая навигация на широком окне, нижняя — на узком.
class AppShell extends StatelessWidget {
  final String location;
  final Widget child;

  const AppShell({super.key, required this.location, required this.child});

  static const _sections = [
    (booksPath, Icons.menu_book, 'Книги'),
    (authorsPath, Icons.person, 'Авторы'),
    (genresPath, Icons.category, 'Жанры'),
    (publishersPath, Icons.apartment, 'Издательства'),
    (readersPath, Icons.badge, 'Читатели'),
  ];

  int get _index {
    final i = _sections.indexWhere((s) => location.startsWith(s.$1));
    return i == -1 ? 0 : i;
  }

  /// Возврат в раздел восстанавливает его последние условия отбора.
  void _select(BuildContext context, int index) {
    final target = switch (index) {
      0 => booksLocation(context.read<BookListNotifier>().query),
      1 => authorsLocation(context.read<AuthorListNotifier>().query),
      2 => listLocation(genresPath, context.read<GenreListNotifier>().query),
      3 => listLocation(publishersPath, context.read<PublisherListNotifier>().query),
      _ => listLocation(readersPath, context.read<ReaderListNotifier>().query),
    };
    context.go(target);
  }

  @override
  Widget build(BuildContext context) {
    final narrow = MediaQuery.sizeOf(context).width < 600;
    if (narrow) {
      return Scaffold(
        body: child,
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => _select(context, i),
          labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
          destinations: [
            for (final s in _sections)
              NavigationDestination(icon: Icon(s.$2), label: s.$3),
          ],
        ),
      );
    }
    return Scaffold(
      body: Row(
        children: [
          NavigationRail(
            selectedIndex: _index,
            onDestinationSelected: (i) => _select(context, i),
            labelType: NavigationRailLabelType.all,
            leading: const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Icon(Icons.local_library, size: 32),
            ),
            destinations: [
              for (final s in _sections)
                NavigationRailDestination(icon: Icon(s.$2), label: Text(s.$3)),
            ],
          ),
          const VerticalDivider(width: 1),
          Expanded(child: child),
        ],
      ),
    );
  }
}
