import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/author.dart';
import '../models/author_details.dart';
import '../router/locations.dart';
import '../state/author_list_notifier.dart';
import '../state/catalog_notifier.dart';
import '../state/details_notifier.dart';
import '../widgets/deleted_badge.dart';
import '../widgets/detail_field.dart';
import '../widgets/dialogs.dart';
import '../widgets/state_views.dart';

/// Карточка автора со списком его книг.
class AuthorDetailsScreen extends StatelessWidget {
  final int id;

  const AuthorDetailsScreen({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    final details = context.watch<DetailsNotifier<AuthorDetails>>();
    final data = details.data;
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(
          onPressed: () => context
              .go(authorsLocation(context.read<AuthorListNotifier>().query)),
        ),
        title: Text(data?.author.fullName ?? 'Автор №$id'),
      ),
      body: DetailsStateView(
        status: details.status,
        error: details.error,
        notFound: details.notFound,
        hasData: data != null,
        notFoundMessage: 'Автора с номером $id нет в каталоге.',
        onRetry: details.load,
        builder: () => _AuthorInfo(details: data!),
      ),
    );
  }
}

class _AuthorInfo extends StatelessWidget {
  final AuthorDetails details;

  const _AuthorInfo({required this.details});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final author = details.author;
    final deletedAt = author.deletedAt;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Align(
        alignment: Alignment.topLeft,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (deletedAt != null)
                DeletedNotice(text: 'Автор удалён ${formatDateTime(deletedAt)}'),
              Text(author.fullName, style: theme.textTheme.headlineSmall),
              const SizedBox(height: 16),
              DetailField(label: 'Страна', child: Text(author.country)),
              DetailField(label: 'Год рождения', child: Text(author.birthYear?.toString() ?? '—')),
              const SizedBox(height: 16),
              Text('Книги в каталоге (${details.books.length})',
                  style: theme.textTheme.titleMedium),
              const SizedBox(height: 8),
              if (details.books.isEmpty)
                const Text('Книг этого автора в каталоге нет.')
              else
                Card(
                  margin: EdgeInsets.zero,
                  child: Column(
                    children: [
                      for (final book in details.books)
                        ListTile(
                          leading: const Icon(Icons.menu_book),
                          title: TitleWithBadge(
                              text: book.title, deleted: book.isDeleted),
                          subtitle: Text('${book.year} · ${book.pages} стр.'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => context.go(bookLocation(book.id)),
                        ),
                    ],
                  ),
                ),
              const SizedBox(height: 24),
              _AuthorActions(author: author),
            ],
          ),
        ),
      ),
    );
  }
}

class _AuthorActions extends StatelessWidget {
  final Author author;

  const _AuthorActions({required this.author});

  Future<void> _softDelete(BuildContext context) async {
    final list = context.read<AuthorListNotifier>();
    final details = context.read<DetailsNotifier<AuthorDetails>>();
    final ok = await confirmAction(
      context,
      title: 'Удалить автора?',
      message: '«${author.fullName}» будет помечен как удалённый.',
    );
    if (!ok) return;
    if (!context.mounted) return;
    final done = await runWithFeedback(
        context, () => list.softDelete(author.id),
        success: 'Автор удалён');
    if (done) await details.load();
  }

  Future<void> _restore(BuildContext context) async {
    final list = context.read<AuthorListNotifier>();
    final details = context.read<DetailsNotifier<AuthorDetails>>();
    final done = await runWithFeedback(context, () => list.restore(author.id),
        success: 'Автор восстановлен');
    if (done) await details.load();
  }

  Future<void> _hardDelete(BuildContext context) async {
    final list = context.read<AuthorListNotifier>();
    final catalog = context.read<CatalogNotifier>();
    final ok = await confirmAction(
      context,
      title: 'Удалить навсегда?',
      message: '«${author.fullName}» будет стёрт без возможности восстановления.',
      confirmLabel: 'Удалить навсегда',
    );
    if (!ok) return;
    if (!context.mounted) return;
    final done = await runWithFeedback(
        context, () => list.hardDelete(author.id),
        success: 'Автор удалён навсегда');
    if (!done) return;
    await catalog.load();
    if (!context.mounted) return;
    context.go(authorsLocation(list.query));
  }

  @override
  Widget build(BuildContext context) {
    final error = Theme.of(context).colorScheme.error;
    return Wrap(
      spacing: 12,
      runSpacing: 8,
      children: [
        if (!author.isDeleted)
          FilledButton.icon(
            onPressed: () => context.go(editLocation(authorsPath, author.id)),
            icon: const Icon(Icons.edit_outlined),
            label: const Text('Изменить'),
          ),
        if (author.isDeleted)
          FilledButton.icon(
            onPressed: () => _restore(context),
            icon: const Icon(Icons.restore_from_trash),
            label: const Text('Восстановить'),
          )
        else
          OutlinedButton.icon(
            onPressed: () => _softDelete(context),
            icon: const Icon(Icons.delete_outline),
            label: const Text('Удалить'),
          ),
        TextButton.icon(
          style: TextButton.styleFrom(foregroundColor: error),
          onPressed: () => _hardDelete(context),
          icon: const Icon(Icons.delete_forever),
          label: const Text('Удалить навсегда'),
        ),
      ],
    );
  }
}
