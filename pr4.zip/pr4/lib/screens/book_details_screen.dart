import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../core/api_exceptions.dart';
import '../models/book.dart';
import '../router/locations.dart';
import '../state/book_list_notifier.dart';
import '../state/catalog_notifier.dart';
import '../state/details_notifier.dart';
import '../state/loan_notifier.dart';
import '../widgets/detail_field.dart';
import '../widgets/dialogs.dart';
import '../widgets/issue_loan_dialog.dart';
import '../forms/validators.dart' show formatDate;
import '../widgets/state_views.dart';

/// Карточка книги.
class BookDetailsScreen extends StatelessWidget {
  final int id;

  const BookDetailsScreen({super.key, required this.id});

  void _backToList(BuildContext context) =>
      context.go(booksLocation(context.read<BookListNotifier>().query));

  @override
  Widget build(BuildContext context) {
    final details = context.watch<DetailsNotifier<Book>>();
    final book = details.data;
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(onPressed: () => _backToList(context)),
        title: Text(book?.title ?? 'Книга №$id'),
      ),
      body: DetailsStateView(
        status: details.status,
        error: details.error,
        notFound: details.notFound,
        hasData: book != null,
        notFoundMessage: 'Книги с номером $id нет в каталоге.',
        onRetry: details.load,
        builder: () => _BookInfo(book: book!),
      ),
    );
  }
}

class _BookInfo extends StatelessWidget {
  final Book book;

  const _BookInfo({required this.book});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final catalog = context.watch<CatalogNotifier>();
    final publisher = catalog.publisher(book.publisherId);
    final deletedAt = book.deletedAt;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Align(
        alignment: Alignment.topLeft,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (deletedAt != null)
                DeletedNotice(text: 'Книга удалена ${formatDateTime(deletedAt)}'),
              Text(book.title, style: theme.textTheme.headlineSmall),
              const SizedBox(height: 16),
              DetailField(
                label: 'Авторы',
                child: Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    for (final authorId in book.authorIds)
                      ActionChip(
                        avatar: const Icon(Icons.person, size: 18),
                        label: Text(
                            catalog.author(authorId)?.fullName ?? 'автор №$authorId'),
                        onPressed: () => context.go(authorLocation(authorId)),
                      ),
                  ],
                ),
              ),
              DetailField(
                label: 'Жанры',
                child: Text(catalog.genreNames(book.genreIds)),
              ),
              DetailField(
                label: 'Издательство',
                child: Text(publisher == null
                    ? catalog.publisherName(book.publisherId)
                    : '${publisher.name} (${publisher.city})'),
              ),
              DetailField(label: 'Год издания', child: Text('${book.year}')),
              DetailField(label: 'Страниц', child: Text('${book.pages}')),
              DetailField(label: 'ISBN', child: SelectableText(book.isbn)),
              DetailField(
                label: 'Экземпляры',
                child: Text(
                    'доступно ${book.copiesAvailable} из ${book.copiesTotal}'),
              ),
              const SizedBox(height: 24),
              _BookActions(book: book),
            ],
          ),
        ),
      ),
    );
  }
}

class _BookActions extends StatelessWidget {
  final Book book;

  const _BookActions({required this.book});

  Future<void> _softDelete(BuildContext context) async {
    final list = context.read<BookListNotifier>();
    final details = context.read<DetailsNotifier<Book>>();
    final ok = await confirmAction(
      context,
      title: 'Удалить книгу?',
      message: '«${book.title}» будет помечена как удалённая.',
    );
    if (!ok) return;
    if (!context.mounted) return;
    final done = await runWithFeedback(context, () => list.softDelete(book.id),
        success: 'Книга удалена');
    if (done) await details.load();
  }

  Future<void> _restore(BuildContext context) async {
    final list = context.read<BookListNotifier>();
    final details = context.read<DetailsNotifier<Book>>();
    final done = await runWithFeedback(context, () => list.restore(book.id),
        success: 'Книга восстановлена');
    if (done) await details.load();
  }

  Future<void> _hardDelete(BuildContext context) async {
    final list = context.read<BookListNotifier>();
    final ok = await confirmAction(
      context,
      title: 'Удалить навсегда?',
      message: '«${book.title}» будет стёрта без возможности восстановления.',
      confirmLabel: 'Удалить навсегда',
    );
    if (!ok) return;
    if (!context.mounted) return;
    final done = await runWithFeedback(context, () => list.hardDelete(book.id),
        success: 'Книга удалена навсегда');
    if (!done) return;
    if (!context.mounted) return;
    context.go(booksLocation(list.query));
  }

  /// Выдача книги. Нет свободных экземпляров — сервер отвечает 409,
  /// и пользователь видит понятное сообщение.
  Future<void> _issue(BuildContext context) async {
    final loans = context.read<LoanNotifier>();
    final details = context.read<DetailsNotifier<Book>>();
    final messenger = ScaffoldMessenger.of(context);
    final choice = await showDialog<(int, int)>(
      context: context,
      builder: (_) =>
          IssueLoanDialog(bookTitle: book.title, readers: loans.readers()),
    );
    if (choice == null || !context.mounted) return;
    try {
      final loan = await loans.issue(
          readerId: choice.$1, bookId: book.id, days: choice.$2);
      messenger.showSnackBar(SnackBar(
          content: Text('Книга выдана: ${loan.readerName}, '
              'вернуть до ${formatDate(loan.dueAt ?? DateTime.now())}')));
      await details.load();
    } on ConflictException catch (e) {
      if (!context.mounted) return;
      await showMessageDialog(context,
          title: 'Выдача невозможна', message: e.message, icon: Icons.block);
    } on ApiException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Не удалось выдать: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final error = Theme.of(context).colorScheme.error;
    return Wrap(
      spacing: 12,
      runSpacing: 8,
      children: [
        if (!book.isDeleted)
          FilledButton.icon(
            onPressed: () => context.go(editLocation(booksPath, book.id)),
            icon: const Icon(Icons.edit_outlined),
            label: const Text('Изменить'),
          ),
        if (!book.isDeleted)
          FilledButton.tonalIcon(
            onPressed: () => _issue(context),
            icon: const Icon(Icons.outbox_outlined),
            label: const Text('Выдать читателю'),
          ),
        if (book.isDeleted)
          FilledButton.icon(
            onPressed: () => _restore(context),
            icon: const Icon(Icons.restore_from_trash),
            label: const Text('Восстановить'),
          )
        else
          OutlinedButton.icon(
            onPressed: () => _softDelete(context),
            icon: const Icon(Icons.delete_outline),
            label: const Text('Удалить'),
          ),
        TextButton.icon(
          style: TextButton.styleFrom(foregroundColor: error),
          onPressed: () => _hardDelete(context),
          icon: const Icon(Icons.delete_forever),
          label: const Text('Удалить навсегда'),
        ),
      ],
    );
  }
}
