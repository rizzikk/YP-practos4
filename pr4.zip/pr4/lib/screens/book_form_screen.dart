import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../forms/entity_form.dart';
import '../forms/validators.dart';
import '../models/book.dart';
import '../router/locations.dart';
import '../state/book_list_notifier.dart';
import '../state/catalog_notifier.dart';

/// Один экран и для новой книги (/books/new), и для изменения (/books/:id/edit).
class BookFormScreen extends StatelessWidget {
  const BookFormScreen({super.key, this.id});

  final int? id;
  bool get isEditing => id != null;

  @override
  Widget build(BuildContext context) {
    final list = context.read<BookListNotifier>();
    final catalog = context.watch<CatalogNotifier>();
    final back = isEditing
        ? detailsLocation(booksPath, id!)
        : booksLocation(list.query);

    return EntityFormPage<Book>(
      title: isEditing ? 'Изменение книги' : 'Новая книга',
      backLocation: back,
      isEditing: isEditing,
      formBuilder: (context, book) => EntityForm(
        key: ValueKey('book-${book?.id}'),
        isEditing: book != null,
        initialValues: {
          'title': book?.title ?? '',
          'isbn': book?.isbn ?? '',
          'year': book?.year.toString() ?? '',
          'pages': book?.pages.toString() ?? '',
          'publisherId': book?.publisherId,
          'authorIds': book?.authorIds ?? <int>[],
          'genreIds': book?.genreIds ?? <int>[],
          'copiesTotal': book?.copiesTotal.toString() ?? '1',
        },
        onCancel: () => context.go(back),
        buildFields: (v) => _fields(v, catalog, book),
        // Уникальность ISBN и существование связанных записей проверяет
        // сервер: ответ 422 общая форма раскладывает по полям.
        onSubmit: (v) async {
          final entity = Book(
            id: book?.id ?? 0,
            title: v.text('title'),
            isbn: v.text('isbn'),
            year: v.intValue('year')!,
            pages: v.intValue('pages')!,
            publisherId: v.choice('publisherId') as int,
            authorIds: v.multi('authorIds'),
            genreIds: v.multi('genreIds'),
            copiesTotal: v.intValue('copiesTotal')!,
            // Доступные экземпляры считает сервер по открытым выдачам.
            copiesAvailable: book?.copiesAvailable ?? v.intValue('copiesTotal')!,
            deletedAt: book?.deletedAt,
          );
          final saved = await list.save(entity, isNew: book == null);
          if (context.mounted) context.go(detailsLocation(booksPath, saved.id));
          return const {};
        },
      ),
    );
  }

  List<FieldSpec> _fields(FormValues v, CatalogNotifier catalog, Book? book) {
    final year = DateTime.now().year;

    // В списках — действующие записи, плюс уже выбранные удалённые
    // (чтобы при изменении старой книги значение не пропало).
    final List<(Object, String)> publishers = [
      for (final p in catalog.publishers) (p.id, p.name),
      if (book != null && catalog.publisher(book.publisherId)?.isDeleted == true)
        (book.publisherId, '${catalog.publisherName(book.publisherId)} (удалено)'),
    ];
    final authors = [
      for (final a in catalog.authors) (a.id, a.fullName),
      for (final id in book?.authorIds ?? const <int>[])
        if (catalog.author(id)?.isDeleted == true)
          (id, '${catalog.author(id)!.fullName} (удалён)'),
    ];
    final genres = [
      for (final g in catalog.genres) (g.id, g.name),
      for (final id in book?.genreIds ?? const <int>[])
        if (catalog.genre(id)?.isDeleted == true)
          (id, '${catalog.genre(id)!.name} (удалён)'),
    ];

    return [
      TextFieldSpec('title', 'Название',
          validator: Validators.all([
            Validators.required(),
            Validators.length(min: 1, max: 200),
          ])),
      TextFieldSpec('isbn', 'ISBN',
          width: 280,
          hint: '978-5-17-090101-1',
          validator: Validators.all([Validators.required(), Validators.isbn()])),
      TextFieldSpec('year', 'Год издания',
          numeric: true,
          width: 160,
          validator: Validators.all([
            Validators.required(),
            Validators.intRange(1450, year),
          ])),
      TextFieldSpec('pages', 'Страниц',
          numeric: true,
          width: 160,
          validator: Validators.all([
            Validators.required(),
            Validators.intRange(1, 10000),
          ])),
      ChoiceFieldSpec('publisherId', 'Издательство',
          options: publishers,
          requiredMessage: 'Выберите издательство',
          helper: 'Многие к одному: у книги одно издательство'),
      MultiChoiceFieldSpec('authorIds', 'Авторы',
          options: authors,
          maxSelected: 10,
          emptyMessage: 'Выберите хотя бы одного автора',
          helper: 'Многие ко многим: у книги может быть несколько авторов'),
      MultiChoiceFieldSpec('genreIds', 'Жанры',
          options: genres,
          emptyMessage: 'Выберите хотя бы один жанр',
          helper: 'Многие ко многим: у книги может быть несколько жанров'),
      TextFieldSpec('copiesTotal', 'Всего экземпляров',
          numeric: true,
          width: 220,
          validator: Validators.all([
            Validators.required(),
            Validators.positive(max: 1000),
          ])),
    ];
  }
}
