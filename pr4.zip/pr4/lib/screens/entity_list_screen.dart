import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/list_query.dart';
import '../router/locations.dart';
import '../state/entity_list_notifier.dart';
import '../state/load_status.dart';
import '../widgets/debounced_text_field.dart';
import '../widgets/dialogs.dart';
import '../widgets/entity_table.dart';
import '../widgets/labeled_dropdown.dart';
import '../widgets/pagination_bar.dart';
import '../widgets/selection_bar.dart';
import '../widgets/state_views.dart';

/// Настройка общего экрана списка для конкретной сущности.
class ListScreenConfig<T> {
  const ListScreenConfig({
    required this.title,
    required this.basePath,
    required this.searchHint,
    required this.addLabel,
    required this.emptyText,
    required this.idOf,
    required this.isDeleted,
    required this.nameOf,
    required this.columns,
    this.filterLabel,
    this.filterAnyLabel = 'Все',
    this.filterOptions,
  });

  final String title;
  final String basePath;
  final String searchHint;
  final String addLabel;
  final String emptyText;
  final int Function(T item) idOf;
  final bool Function(T item) isDeleted;
  final String Function(T item) nameOf;
  final List<TableColumnSpec<T>> Function(BuildContext context) columns;
  final String? filterLabel;
  final String filterAnyLabel;

  /// Варианты фильтра «значение в адресе — подпись».
  final Map<String, String> Function(BuildContext context)? filterOptions;
}

/// Общий экран списка: поиск с задержкой, фильтр, сортировка по заголовку,
/// постраничный вывод, выделение, логическое и физическое удаление,
/// восстановление. Условия отбора берутся из адреса.
class EntityListScreen<T, N extends EntityListNotifier<T, ListQuery>>
    extends StatefulWidget {
  const EntityListScreen({super.key, required this.config, required this.query});

  final ListScreenConfig<T> config;
  final ListQuery query;

  @override
  State<EntityListScreen<T, N>> createState() => _EntityListScreenState<T, N>();
}

class _EntityListScreenState<T, N extends EntityListNotifier<T, ListQuery>>
    extends State<EntityListScreen<T, N>> {
  bool _filtersExpanded = false;

  ListScreenConfig<T> get _c => widget.config;
  ListQuery get _q => widget.query;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<N>().applyQuery(_q);
    });
  }

  @override
  void didUpdateWidget(EntityListScreen<T, N> oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.query != widget.query) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.read<N>().syncWithQuery(_q);
      });
    }
  }

  void _go(ListQuery next) {
    if (next == _q) return;
    context.go(listLocation(_c.basePath, next));
  }

  void _sort(String field) => _go(_q.copyWith(
        sortField: field,
        sortAscending: field == _q.sortField ? !_q.sortAscending : true,
      ));

  void _fixPageOverflow(N list) {
    final r = list.result;
    if (list.status == LoadStatus.success &&
        r.items.isEmpty &&
        r.total > 0 &&
        list.query.page > r.totalPages) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _go(_q.copyWith(page: r.totalPages));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = context.watch<N>();
    final result = list.result;
    final narrow = MediaQuery.sizeOf(context).width < EntityTable.cardBreakpoint;
    _fixPageOverflow(list);

    return Scaffold(
      appBar: AppBar(
        title: Text(_c.title),
        actions: [
          IconButton(
            tooltip: 'Обновить',
            icon: const Icon(Icons.refresh),
            onPressed: list.load,
          ),
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: narrow
                ? IconButton(
                    tooltip: _c.addLabel,
                    icon: const Icon(Icons.add),
                    onPressed: () => context.go(newLocation(_c.basePath)),
                  )
                : FilledButton.icon(
                    onPressed: () => context.go(newLocation(_c.basePath)),
                    icon: const Icon(Icons.add),
                    label: Text(_c.addLabel),
                  ),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildFilters(narrow),
          if (list.hasSelection)
            SelectionBar(
              count: list.selected.length,
              onDelete: () => _deleteSelected(list),
              onClear: list.clearSelection,
            ),
          Expanded(
            child: ListStateView(
              status: list.status,
              error: list.error,
              hasData: result.items.isNotEmpty,
              emptyTitle: _q.hasFilters ? 'Ничего не найдено' : 'Список пуст',
              emptyMessage: _q.hasFilters
                  ? 'Ни одна запись не подходит под условия отбора.'
                  : _c.emptyText,
              onRetry: list.load,
              onResetFilters: _q.hasFilters ? () => _go(_q.clearFilters()) : null,
              child: EntityTable<T>(
                items: result.items,
                idOf: _c.idOf,
                isInactive: _c.isDeleted,
                selected: list.selected,
                onToggleSelect: list.toggleSelection,
                onSelectAll: (value) =>
                    list.setSelection(result.items.map(_c.idOf), value),
                sortField: _q.sortField,
                sortAscending: _q.sortAscending,
                onSort: _sort,
                onOpen: (item) =>
                    context.go(detailsLocation(_c.basePath, _c.idOf(item))),
                columns: _c.columns(context),
                actions: (item) => _rowActions(list, item),
              ),
            ),
          ),
          if (list.status != LoadStatus.error && result.total > 0)
            PaginationBar(
              result: result,
              size: _q.size,
              onPage: (page) => _go(_q.copyWith(page: page)),
              onSize: (size) => _go(_q.copyWith(size: size)),
            ),
        ],
      ),
    );
  }

  Widget _buildFilters(bool narrow) {
    final search = DebouncedTextField(
      value: _q.search,
      label: 'Поиск',
      hint: _c.searchHint,
      icon: Icons.search,
      width: narrow ? null : 300,
      onChanged: (v) => _go(_q.copyWith(search: v)),
    );
    final options = _c.filterOptions?.call(context);
    final filters = <Widget>[
      if (options != null)
        LabeledDropdown<String>(
          label: _c.filterLabel ?? 'Фильтр',
          anyLabel: _c.filterAnyLabel,
          width: narrow ? null : 220,
          value: _q.filter,
          options: options,
          onChanged: (v) => _go(_q.copyWith(filter: v)),
        ),
      FilterChip(
        label: const Text('Показывать удалённые'),
        selected: _q.includeDeleted,
        onSelected: (v) => _go(_q.copyWith(includeDeleted: v)),
      ),
      if (_q.hasFilters)
        TextButton.icon(
          onPressed: () => _go(_q.clearFilters()),
          icon: const Icon(Icons.filter_alt_off),
          label: const Text('Сбросить'),
        ),
    ];

    if (!narrow) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        child: Wrap(
          spacing: 12,
          runSpacing: 12,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [search, ...filters],
        ),
      );
    }
    final count = _q.activeFilterCount;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(child: search),
              IconButton(
                tooltip: 'Фильтры',
                isSelected: _filtersExpanded,
                icon: Badge(
                  isLabelVisible: count > 0,
                  label: Text('$count'),
                  child: const Icon(Icons.tune),
                ),
                onPressed: () =>
                    setState(() => _filtersExpanded = !_filtersExpanded),
              ),
            ],
          ),
          if (_filtersExpanded)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Wrap(spacing: 8, runSpacing: 8, children: filters),
            ),
        ],
      ),
    );
  }

  List<Widget> _rowActions(N list, T item) {
    final id = _c.idOf(item);
    if (_c.isDeleted(item)) {
      return [
        IconButton(
          tooltip: 'Восстановить',
          icon: const Icon(Icons.restore_from_trash),
          onPressed: () => runWithFeedback(context, () => list.restore(id),
              success: '«${_c.nameOf(item)}» восстановлено'),
        ),
        IconButton(
          tooltip: 'Удалить навсегда',
          icon: Icon(Icons.delete_forever,
              color: Theme.of(context).colorScheme.error),
          onPressed: () => _delete(list, item, hard: true),
        ),
      ];
    }
    return [
      IconButton(
        tooltip: 'Изменить',
        icon: const Icon(Icons.edit_outlined),
        onPressed: () => context.go(editLocation(_c.basePath, id)),
      ),
      IconButton(
        tooltip: 'Удалить',
        icon: const Icon(Icons.delete_outline),
        onPressed: () => _delete(list, item, hard: false),
      ),
    ];
  }

  Future<void> _delete(N list, T item, {required bool hard}) async {
    final id = _c.idOf(item);
    final name = _c.nameOf(item);
    await confirmAndDelete(
      context,
      list: list,
      id: id,
      name: name,
      hard: hard,
    );
  }

  Future<void> _deleteSelected(N list) async {
    final count = list.selected.length;
    final ok = await confirmAction(
      context,
      title: 'Удалить выбранные записи?',
      message: 'Выбрано записей: $count. Они будут помечены как удалённые; '
          'уже удалённые записи пропускаются.',
      confirmLabel: 'Удалить ($count)',
    );
    if (!ok) return;
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      final r = await list.deleteSelected();
      messenger.showSnackBar(SnackBar(content: Text('Удалено записей: ${r.deleted}')));
      if (r.blocked.isEmpty) return;
      if (!mounted) return;
      await showMessageDialog(context,
          title: 'Часть записей не удалена', message: r.blocked.join('\n\n'));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Ошибка: $e')));
    }
  }
}

/// Удаление с проверкой правил целостности и подтверждением. Если удаление
/// запрещено, вместо подтверждения показывается причина.
Future<bool> confirmAndDelete<T, Q>(
  BuildContext context, {
  required EntityListNotifier<T, Q> list,
  required int id,
  required String name,
  required bool hard,
}) async {
  try {
    await list.ensureCanDelete(id);
  } on DeleteBlockedException catch (e) {
    if (context.mounted) {
      await showMessageDialog(context,
          title: 'Удаление невозможно', message: e.message);
    }
    return false;
  }
  if (!context.mounted) return false;
  final ok = await confirmAction(
    context,
    title: hard ? 'Удалить навсегда?' : 'Удалить запись?',
    message: hard
        ? '«$name» будет стёрто без возможности восстановления.'
        : '«$name» будет помечено как удалённое. Запись можно восстановить, '
            'включив показ удалённых.',
    confirmLabel: hard ? 'Удалить навсегда' : 'Удалить',
  );
  if (!ok) return false;
  if (!context.mounted) return false;
  return runWithFeedback(
    context,
    () => hard ? list.hardDelete(id) : list.softDelete(id),
    success: hard ? '«$name» удалено навсегда' : '«$name» удалено',
  );
}
