import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../forms/entity_form.dart';
import '../forms/validators.dart';
import '../models/book.dart';
import '../models/list_query.dart';
import '../models/publisher.dart';
import '../router/locations.dart';
import '../state/details_notifier.dart';
import '../state/list_notifiers.dart';
import '../widgets/deleted_badge.dart';
import '../widgets/detail_field.dart';
import '../widgets/dialogs.dart';
import '../widgets/entity_table.dart';
import '../widgets/state_views.dart';
import 'entity_list_screen.dart';

typedef PublisherDetails = ({Publisher publisher, List<Book> books});

final publisherListConfig = ListScreenConfig<Publisher>(
  title: 'Издательства',
  basePath: publishersPath,
  searchHint: 'Название или город',
  addLabel: 'Добавить издательство',
  emptyText: 'Издательств пока нет.',
  idOf: (p) => p.id,
  isDeleted: (p) => p.isDeleted,
  nameOf: (p) => p.name,
  columns: (context) {
    return [
      TableColumnSpec<Publisher>(
        label: 'Название',
        sortField: 'name',
        build: (p) => TitleWithBadge(text: p.name, deleted: p.isDeleted),
      ),
      TableColumnSpec<Publisher>(
          label: 'Город', sortField: 'city', build: (p) => Text(p.city)),
      TableColumnSpec<Publisher>(
        label: 'Основано',
        sortField: 'foundedYear',
        numeric: true,
        build: (p) => Text(p.foundedYear?.toString() ?? '—'),
      ),
    ];
  },
);

class PublishersListScreen extends StatelessWidget {
  const PublishersListScreen({super.key, required this.query});
  final ListQuery query;

  @override
  Widget build(BuildContext context) =>
      EntityListScreen<Publisher, PublisherListNotifier>(
          config: publisherListConfig, query: query);
}

class PublisherDetailsScreen extends StatelessWidget {
  const PublisherDetailsScreen({super.key, required this.id});
  final int id;

  @override
  Widget build(BuildContext context) {
    final details = context.watch<DetailsNotifier<PublisherDetails>>();
    final data = details.data;
    final list = context.read<PublisherListNotifier>();
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(
            onPressed: () => context.go(listLocation(publishersPath, list.query))),
        title: Text(data?.publisher.name ?? 'Издательство №$id'),
      ),
      body: DetailsStateView(
        status: details.status,
        error: details.error,
        notFound: details.notFound,
        hasData: data != null,
        notFoundMessage: 'Издательства с номером $id нет.',
        onRetry: details.load,
        builder: () {
          final p = data!.publisher;
          final deletedAt = p.deletedAt;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Align(
              alignment: Alignment.topLeft,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 760),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (deletedAt != null)
                      DeletedNotice(
                          text: 'Издательство удалено ${formatDateTime(deletedAt)}'),
                    Text(p.name, style: Theme.of(context).textTheme.headlineSmall),
                    const SizedBox(height: 16),
                    DetailField(label: 'Город', child: Text(p.city)),
                    DetailField(
                        label: 'Основано',
                        child: Text(p.foundedYear?.toString() ?? '—')),
                    const SizedBox(height: 16),
                    RelatedList(
                      title: 'Книги издательства',
                      emptyText: 'Книг этого издательства в каталоге нет.',
                      items: [
                        for (final b in data.books)
                          (
                            b.title,
                            '${b.year} · ISBN ${b.isbn}',
                            b.isDeleted,
                            () => context.go(detailsLocation(booksPath, b.id)),
                          ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    DetailsActionsBar(
                      isDeleted: p.isDeleted,
                      onEdit: () => context.go(editLocation(publishersPath, id)),
                      onDelete: () => _delete(context, p, hard: false),
                      onRestore: () async {
                        final ok = await runWithFeedback(
                            context, () => list.restore(id),
                            success: 'Издательство восстановлено');
                        if (ok) await details.load();
                      },
                      onHardDelete: () => _delete(context, p, hard: true),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _delete(BuildContext context, Publisher p, {required bool hard}) async {
    final list = context.read<PublisherListNotifier>();
    final details = context.read<DetailsNotifier<PublisherDetails>>();
    final done = await confirmAndDelete(context,
        list: list, id: p.id, name: p.name, hard: hard);
    if (!done) return;
    if (hard) {
      if (context.mounted) context.go(listLocation(publishersPath, list.query));
    } else {
      await details.load();
    }
  }
}

class PublisherFormScreen extends StatelessWidget {
  const PublisherFormScreen({super.key, this.id});
  final int? id;

  @override
  Widget build(BuildContext context) {
    final list = context.read<PublisherListNotifier>();
    final back = id == null
        ? listLocation(publishersPath, list.query)
        : detailsLocation(publishersPath, id!);
    final now = DateTime.now().year;
    return EntityFormPage<Publisher>(
      title: id == null ? 'Новое издательство' : 'Изменение издательства',
      backLocation: back,
      isEditing: id != null,
      formBuilder: (context, p) => EntityForm(
        key: ValueKey('publisher-${p?.id}'),
        isEditing: p != null,
        initialValues: {
          'name': p?.name ?? '',
          'city': p?.city ?? '',
          'foundedYear': p?.foundedYear?.toString() ?? '',
        },
        onCancel: () => context.go(back),
        buildFields: (v) => [
          TextFieldSpec('name', 'Название',
              validator: Validators.all([
                Validators.required(),
                Validators.length(min: 2, max: 100),
              ])),
          TextFieldSpec('city', 'Город',
              width: 300,
              validator: Validators.all([
                Validators.required(),
                Validators.length(min: 2, max: 60),
                Validators.letters(),
              ])),
          TextFieldSpec('foundedYear', 'Год основания',
              numeric: true,
              width: 180,
              helper: 'Необязательно',
              validator: Validators.intRange(1400, now)),
        ],
        onSubmit: (v) async {
          final entity = Publisher(
            id: p?.id ?? 0,
            name: v.text('name'),
            city: v.text('city'),
            foundedYear: v.intValue('foundedYear'),
            deletedAt: p?.deletedAt,
          );
          final saved = await list.save(entity, isNew: p == null);
          if (context.mounted) {
            context.go(detailsLocation(publishersPath, saved.id));
          }
          return const {};
        },
      ),
    );
  }
}
