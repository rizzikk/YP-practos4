import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../forms/entity_form.dart';
import '../forms/validators.dart';
import '../models/list_query.dart';
import '../models/reader.dart';
import '../router/locations.dart';
import '../state/details_notifier.dart';
import '../state/list_notifiers.dart';
import '../widgets/deleted_badge.dart';
import '../widgets/detail_field.dart';
import '../widgets/dialogs.dart';
import '../widgets/entity_table.dart';
import '../widgets/state_views.dart';
import 'entity_list_screen.dart';

/// Метка состояния билета.
class CardStatus extends StatelessWidget {
  const CardStatus({super.key, required this.card});
  final LibraryCard card;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final expired = card.isExpired;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: expired ? scheme.errorContainer : scheme.secondaryContainer,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        expired ? 'истёк' : 'действует',
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
            color: expired ? scheme.onErrorContainer : scheme.onSecondaryContainer),
      ),
    );
  }
}

final readerListConfig = ListScreenConfig<Reader>(
  title: 'Читатели',
  basePath: readersPath,
  searchHint: 'ФИО, почта или телефон',
  addLabel: 'Добавить читателя',
  emptyText: 'Читателей пока нет.',
  idOf: (r) => r.id,
  isDeleted: (r) => r.isDeleted,
  nameOf: (r) => r.fullName,
  columns: (_) => [
    TableColumnSpec<Reader>(
      label: 'Читатель',
      sortField: 'fullName',
      build: (r) => TitleWithBadge(text: r.fullName, deleted: r.isDeleted),
    ),
    TableColumnSpec<Reader>(
        label: 'Почта', sortField: 'email', build: (r) => Text(r.email)),
    TableColumnSpec<Reader>(label: 'Телефон', build: (r) => Text(r.phone ?? '—')),
    TableColumnSpec<Reader>(
        label: 'Билет', build: (r) => Text(r.card?.number ?? '—')),
    TableColumnSpec<Reader>(
      label: 'Действует до',
      build: (r) {
        final card = r.card;
        if (card == null) return const Text('—');
        return Wrap(
          spacing: 6,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [Text(formatDate(card.expiresAt)), CardStatus(card: card)],
        );
      },
    ),
  ],
);

class ReadersListScreen extends StatelessWidget {
  const ReadersListScreen({super.key, required this.query});
  final ListQuery query;

  @override
  Widget build(BuildContext context) =>
      EntityListScreen<Reader, ReaderListNotifier>(config: readerListConfig, query: query);
}

class ReaderDetailsScreen extends StatelessWidget {
  const ReaderDetailsScreen({super.key, required this.id});
  final int id;

  @override
  Widget build(BuildContext context) {
    final details = context.watch<DetailsNotifier<Reader>>();
    final reader = details.data;
    final list = context.read<ReaderListNotifier>();
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(
            onPressed: () => context.go(listLocation(readersPath, list.query))),
        title: Text(reader?.fullName ?? 'Читатель №$id'),
      ),
      body: DetailsStateView(
        status: details.status,
        error: details.error,
        notFound: details.notFound,
        hasData: reader != null,
        notFoundMessage: 'Читателя с номером $id нет.',
        onRetry: details.load,
        builder: () {
          final r = reader!;
          final card = r.card;
          final deletedAt = r.deletedAt;
          final scheme = Theme.of(context).colorScheme;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Align(
              alignment: Alignment.topLeft,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 760),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (deletedAt != null)
                      DeletedNotice(text: 'Читатель удалён ${formatDateTime(deletedAt)}'),
                    Text(r.fullName, style: Theme.of(context).textTheme.headlineSmall),
                    const SizedBox(height: 16),
                    DetailField(label: 'Почта', child: SelectableText(r.email)),
                    DetailField(label: 'Телефон', child: Text(r.phone ?? '—')),
                    const SizedBox(height: 12),
                    if (card == null)
                      const DetailField(label: 'Билет', child: Text('ещё не оформлен'))
                    else
                    DecoratedBox(
                      decoration: BoxDecoration(
                        color: scheme.surfaceContainerLow,
                        border: Border.all(color: scheme.outlineVariant),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              const Icon(Icons.badge_outlined, size: 20),
                              const SizedBox(width: 8),
                              Text('Читательский билет',
                                  style: Theme.of(context).textTheme.titleMedium),
                              const SizedBox(width: 8),
                              CardStatus(card: card),
                            ]),
                            const SizedBox(height: 8),
                            DetailField(label: 'Номер', child: Text(card.number)),
                            DetailField(
                                label: 'Выдан', child: Text(formatDate(card.issuedAt))),
                            DetailField(
                                label: 'Действует до',
                                child: Text(formatDate(card.expiresAt))),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    DetailsActionsBar(
                      isDeleted: r.isDeleted,
                      onEdit: () => context.go(editLocation(readersPath, id)),
                      onDelete: () => _delete(context, r, hard: false),
                      onRestore: () async {
                        final ok = await runWithFeedback(
                            context, () => list.restore(id),
                            success: 'Читатель восстановлен');
                        if (ok) await details.load();
                      },
                      onHardDelete: () => _delete(context, r, hard: true),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _delete(BuildContext context, Reader r, {required bool hard}) async {
    final list = context.read<ReaderListNotifier>();
    final details = context.read<DetailsNotifier<Reader>>();
    final done = await confirmAndDelete(context,
        list: list, id: r.id, name: r.fullName, hard: hard);
    if (!done) return;
    if (hard) {
      if (context.mounted) context.go(listLocation(readersPath, list.query));
    } else {
      await details.load();
    }
  }
}

class ReaderFormScreen extends StatelessWidget {
  const ReaderFormScreen({super.key, this.id});
  final int? id;

  @override
  Widget build(BuildContext context) {
    final list = context.read<ReaderListNotifier>();
    final back = id == null
        ? listLocation(readersPath, list.query)
        : detailsLocation(readersPath, id!);
    return EntityFormPage<Reader>(
      title: id == null ? 'Новый читатель' : 'Изменение читателя',
      backLocation: back,
      isEditing: id != null,
      formBuilder: (context, r) => EntityForm(
        key: ValueKey('reader-${r?.id}'),
        isEditing: r != null,
        initialValues: {
          'fullName': r?.fullName ?? '',
          'email': r?.email ?? '',
          'phone': r?.phone ?? '',
          'cardNumber': r?.card?.number ?? 'оформляется библиотекой',
          'issuedAt': r?.card == null ? '—' : formatDate(r!.card!.issuedAt),
          'expiresAt': r?.card == null ? '—' : formatDate(r!.card!.expiresAt),
        },
        onCancel: () => context.go(back),
        buildFields: (v) => [
          TextFieldSpec('fullName', 'ФИО',
              hint: 'Смирнов П. А.',
              validator: Validators.all([
                Validators.required(),
                Validators.length(min: 2, max: 100),
                Validators.letters(),
              ])),
          TextFieldSpec('email', 'Почта',
              width: 300,
              hint: 'name@example.ru',
              validator: Validators.all([
                Validators.required(),
                Validators.length(max: 100),
                Validators.email(),
              ])),
          TextFieldSpec('phone', 'Телефон',
              width: 300,
              hint: '+7 900 000-00-00',
              helper: 'Необязательно',
              validator: Validators.phone()),
          // Один к одному: билет показан вложенной группой. Номер и сроки
          // назначает сервер, поэтому поля только для чтения.
          const GroupSpec('card', 'Читательский билет', icon: Icons.badge_outlined, [
            TextFieldSpec('cardNumber', 'Номер билета', width: 220, readOnly: true),
            TextFieldSpec('issuedAt', 'Дата выдачи', width: 200, readOnly: true),
            TextFieldSpec('expiresAt', 'Действует до', width: 200, readOnly: true),
          ]),
        ],
        onSubmit: (v) async {
          final phone = v.text('phone');
          final entity = Reader(
            id: r?.id ?? 0,
            fullName: v.text('fullName'),
            email: v.text('email'),
            phone: phone.isEmpty ? null : phone,
            card: r?.card,
            deletedAt: r?.deletedAt,
          );
          final saved = await list.save(entity, isNew: r == null);
          if (context.mounted) context.go(detailsLocation(readersPath, saved.id));
          return const {};
        },
      ),
    );
  }
}
