import 'package:flutter/foundation.dart';

import '../models/author.dart';
import '../models/genre.dart';
import '../models/publisher.dart';
import '../repositories/author_repository.dart';
import '../repositories/reference_repository.dart';
import 'load_status.dart';

/// Справочники: жанры, издательства, авторы. Из них заполняются выпадающие
/// списки и множественный выбор в формах, по ним выводятся названия вместо
/// идентификаторов. Перечитываются после каждого изменения этих сущностей.
class CatalogNotifier extends ChangeNotifier {
  CatalogNotifier(this._genres, this._publishers, this._authors);

  final GenreRepository _genres;
  final PublisherRepository _publishers;
  final AuthorRepository _authors;

  Map<int, Genre> _genreById = const {};
  Map<int, Publisher> _publisherById = const {};
  Map<int, Author> _authorById = const {};
  LoadStatus _status = LoadStatus.idle;

  LoadStatus get status => _status;

  /// Действующие (не удалённые) записи, отсортированные по названию —
  /// для выпадающих списков и фильтров.
  List<Genre> get genres => _genreById.values.where((g) => !g.isDeleted).toList()
    ..sort((a, b) => a.name.compareTo(b.name));
  List<Publisher> get publishers =>
      _publisherById.values.where((p) => !p.isDeleted).toList()
        ..sort((a, b) => a.name.compareTo(b.name));
  List<Author> get authors =>
      _authorById.values.where((a) => !a.isDeleted).toList()
        ..sort((a, b) => a.fullName.compareTo(b.fullName));
  List<String> get countries =>
      _authorById.values.map((a) => a.country).toSet().toList()..sort();
  List<String> get cities =>
      _publisherById.values.map((p) => p.city).toSet().toList()..sort();

  Future<void> load() async {
    _status = LoadStatus.loading;
    notifyListeners();
    try {
      final genres = await _genres.findAll();
      final publishers = await _publishers.findAll();
      final authors = await _authors.findAll();
      _genreById = {for (final g in genres) g.id: g};
      _publisherById = {for (final p in publishers) p.id: p};
      _authorById = {for (final a in authors) a.id: a};
      _status = LoadStatus.success;
    } catch (_) {
      _status = LoadStatus.error;
    }
    notifyListeners();
  }

  Author? author(int id) => _authorById[id];
  Publisher? publisher(int id) => _publisherById[id];
  Genre? genre(int id) => _genreById[id];

  String genreNames(List<int> ids) =>
      _join(ids.map((id) => _genreById[id]?.name ?? '#$id'));

  String publisherName(int id) => _publisherById[id]?.name ?? '#$id';

  String authorNames(List<int> ids) =>
      _join(ids.map((id) => _authorById[id]?.shortName ?? 'автор #$id'));

  static String _join(Iterable<String> parts) =>
      parts.isEmpty ? '—' : parts.join(', ');
}
