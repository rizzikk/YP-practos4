import 'package:flutter/foundation.dart';

import '../models/page_result.dart';
import '../repositories/crud_repository.dart';
import 'load_status.dart';

/// Удаление запрещено правилом целостности (например, на издательство
/// ссылаются книги). [message] показывается пользователю.
class DeleteBlockedException implements Exception {
  const DeleteBlockedException(this.message);
  final String message;

  @override
  String toString() => message;
}

/// Проверка перед удалением: текст причины отказа или `null`, если можно.
typedef DeleteGuard = Future<String?> Function(int id);

/// Состояние экрана списка: условия отбора, текущая страница, статус загрузки
/// и выделенные записи. Обобщён по типу записи [T] и типу условий [Q], поэтому
/// все пять сущностей используют одну и ту же реализацию.
abstract class EntityListNotifier<T, Q> extends ChangeNotifier {
  EntityListNotifier(
    this._repository,
    Q initialQuery, {
    VoidCallback? onChanged,
    DeleteGuard? deleteGuard,
  })  : _query = initialQuery,
        _onChanged = onChanged,
        _deleteGuard = deleteGuard;

  final CrudRepository<T, Q> _repository;
  final VoidCallback? _onChanged;
  final DeleteGuard? _deleteGuard;

  Q _query;
  PageResult<T> _result = PageResult<T>.empty();
  LoadStatus _status = LoadStatus.idle;
  String? _error;
  final Set<int> _selected = {};

  /// Номер последнего запроса. Ответ на устаревший запрос (условия успели
  /// смениться, пока он выполнялся) отбрасывается.
  int _request = 0;

  Q get query => _query;
  PageResult<T> get result => _result;
  LoadStatus get status => _status;
  String? get error => _error;
  Set<int> get selected => Set.unmodifiable(_selected);
  bool get hasSelection => _selected.isNotEmpty;

  Future<void> load() async {
    final request = ++_request;
    _status = LoadStatus.loading;
    _error = null;
    notifyListeners();

    try {
      final result = await _repository.find(_query);
      if (request != _request) return;
      _result = result;
      _status = LoadStatus.success;
    } catch (e) {
      if (request != _request) return;
      _error = 'Не удалось загрузить список: $e';
      _status = LoadStatus.error;
    }
    // Вызов и в конце загрузки, иначе индикатор не исчезнет.
    notifyListeners();
  }

  Future<void> applyQuery(Q next) async {
    _query = next;
    _selected.clear(); // выделение теряет смысл при смене условий отбора
    await load();
  }

  /// Синхронизация с адресом: перезапрос только если условия действительно
  /// изменились (или список ещё не загружался).
  Future<void> syncWithQuery(Q next) async {
    if (next == _query && _status != LoadStatus.idle) return;
    await applyQuery(next);
  }

  void toggleSelection(int id) {
    if (!_selected.remove(id)) _selected.add(id);
    notifyListeners();
  }

  /// Выделить или снять выделение со всех записей текущей страницы.
  void setSelection(Iterable<int> ids, bool value) {
    if (value) {
      _selected.addAll(ids);
    } else {
      _selected.removeAll(ids);
    }
    notifyListeners();
  }

  void clearSelection() {
    _selected.clear();
    notifyListeners();
  }

  /// Создать ([isNew]) или изменить запись из формы.
  Future<T> save(T entity, {required bool isNew}) async {
    final saved = isNew
        ? await _repository.create(entity)
        : await _repository.update(entity);
    await _afterChange();
    return saved;
  }

  /// Проверить, можно ли удалить запись; при запрете — исключение с причиной.
  Future<void> ensureCanDelete(int id) async {
    final reason = await _deleteGuard?.call(id);
    if (reason != null) throw DeleteBlockedException(reason);
  }

  /// Логическое удаление выбранных. Записи, удаление которых запрещено,
  /// пропускаются, причины возвращаются в [blocked].
  Future<({int deleted, List<String> blocked})> deleteSelected() async {
    final allowed = <int>[];
    final blocked = <String>[];
    for (final id in _selected) {
      final reason = await _deleteGuard?.call(id);
      if (reason == null) {
        allowed.add(id);
      } else {
        blocked.add(reason);
      }
    }
    final count = await _repository.deleteMany(allowed);
    _selected.clear();
    await _afterChange();
    return (deleted: count, blocked: blocked);
  }

  Future<void> softDelete(int id) async {
    await ensureCanDelete(id);
    await _repository.softDelete(id);
    _selected.remove(id);
    await _afterChange();
  }

  Future<void> hardDelete(int id) async {
    await ensureCanDelete(id);
    await _repository.hardDelete(id);
    _selected.remove(id);
    await _afterChange();
  }

  Future<void> restore(int id) async {
    await _repository.restore(id);
    await _afterChange();
  }

  Future<void> _afterChange() async {
    _onChanged?.call();
    if (_status != LoadStatus.idle) await load();
  }
}
