import 'package:flutter/foundation.dart';

import '../models/genre.dart';
import '../models/list_query.dart';
import '../models/publisher.dart';
import '../models/reader.dart';
import '../repositories/book_repository.dart';
import '../repositories/reader_repository.dart';
import '../repositories/reference_repository.dart';
import 'entity_list_notifier.dart';

/// Настройки списков: допустимые поля сортировки, поле по умолчанию и имя
/// параметра фильтра в адресе. Используются и роутером, и состоянием.
class ListSpec {
  const ListSpec(this.sortFields, this.defaultSort, this.filterParam);
  final Set<String> sortFields;
  final String defaultSort;
  final String filterParam;

  ListQuery get initialQuery =>
      ListQuery(defaultSort: defaultSort, filterParam: filterParam);

  ListQuery parse(Map<String, String> params) => ListQuery.fromQueryParameters(
        params,
        sortFields: sortFields,
        defaultSort: defaultSort,
        filterParam: filterParam,
      );
}

// Поля сортировки совпадают с именами полей на сервере.
const genreListSpec = ListSpec({'name'}, 'name', 'filter');
const publisherListSpec =
    ListSpec({'name', 'city', 'foundedYear'}, 'name', 'filter');
const readerListSpec = ListSpec({'fullName', 'email'}, 'fullName', 'filter');

class GenreListNotifier extends EntityListNotifier<Genre, ListQuery> {
  GenreListNotifier(GenreRepository repository, {VoidCallback? onChanged})
      : super(repository, genreListSpec.initialQuery, onChanged: onChanged);
}

class PublisherListNotifier extends EntityListNotifier<Publisher, ListQuery> {
  PublisherListNotifier(
    PublisherRepository repository,
    BookRepository books, {
    VoidCallback? onChanged,
  }) : super(
          repository,
          publisherListSpec.initialQuery,
          onChanged: onChanged,
          // Издательство нельзя удалить, пока на него ссылаются книги.
          deleteGuard: (id) async {
            final count = await books.countByPublisher(id);
            if (count == 0) return null;
            final publisher = await repository.findById(id);
            return 'Нельзя удалить издательство «${publisher?.name ?? id}»: '
                'на него ссылается ${booksCount(count)}. '
                'Сначала измените издательство у этих книг или удалите их.';
          },
        );
}

class ReaderListNotifier extends EntityListNotifier<Reader, ListQuery> {
  ReaderListNotifier(ReaderRepository repository)
      : super(repository, readerListSpec.initialQuery);
}

/// «1 книга», «3 книги», «11 книг».
String booksCount(int n) {
  final mod10 = n % 10, mod100 = n % 100;
  final word = mod10 == 1 && mod100 != 11
      ? 'книга'
      : mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)
          ? 'книги'
          : 'книг';
  return '$n $word';
}
