import '../models/loan.dart';
import '../models/reader.dart';
import '../repositories/loan_repository.dart';
import '../repositories/reader_repository.dart';
import 'list_notifiers.dart';

/// Оформление выдач. Экраны работают с ним, а не с репозиториями напрямую.
class LoanNotifier {
  LoanNotifier(this._loans, this._readers);

  final LoanRepository _loans;
  final ReaderRepository _readers;

  /// Действующие читатели для выбора в диалоге выдачи.
  Future<List<Reader>> readers() async {
    final page =
        await _readers.find(readerListSpec.initialQuery.copyWith(size: 100));
    return page.items;
  }

  /// Нет свободных экземпляров — сервер ответит 409 (ConflictException).
  Future<Loan> issue({required int readerId, required int bookId, int days = 14}) =>
      _loans.issue(readerId: readerId, bookId: bookId, days: days);
}
