import 'package:flutter/material.dart';

/// Описание одной колонки обобщённой таблицы.
class TableColumnSpec<T> {
  final String label;

  /// Поле сортировки; `null` — колонка не сортируется.
  final String? sortField;
  final bool numeric;
  final Widget Function(T item) build;

  const TableColumnSpec({
    required this.label,
    required this.build,
    this.sortField,
    this.numeric = false,
  });
}

/// Обобщённая таблица записей: флажки выделения, сортировка по щелчку на
/// заголовке, действия в строке, двумерная прокрутка. На узком окне
/// (меньше [cardBreakpoint]) вместо таблицы показывается список карточек.
///
/// Используется и для книг, и для авторов — различается только [columns].
class EntityTable<T> extends StatelessWidget {
  static const double cardBreakpoint = 600;

  final List<TableColumnSpec<T>> columns;
  final List<T> items;
  final int Function(T item) idOf;
  final Set<int> selected;
  final ValueChanged<int>? onToggleSelect;
  final ValueChanged<bool>? onSelectAll;
  final String? sortField;
  final bool sortAscending;
  final void Function(String field)? onSort;
  final List<Widget> Function(T item)? actions;
  final ValueChanged<T>? onOpen;

  /// Неактивные (например, удалённые) записи выводятся приглушённо.
  final bool Function(T item)? isInactive;

  const EntityTable({
    super.key,
    required this.columns,
    required this.items,
    required this.idOf,
    this.selected = const {},
    this.onToggleSelect,
    this.onSelectAll,
    this.sortField,
    this.sortAscending = true,
    this.onSort,
    this.actions,
    this.onOpen,
    this.isInactive,
  });

  bool get _selectable => onToggleSelect != null;

  @override
  Widget build(BuildContext context) {
    final narrow = MediaQuery.sizeOf(context).width < cardBreakpoint;
    return narrow ? _buildCards(context) : _buildTable(context);
  }

  // ---------------------------------------------------------------- таблица

  int? get _sortColumnIndex {
    if (sortField == null) return null;
    final i = columns.indexWhere((c) => c.sortField == sortField);
    return i == -1 ? null : i;
  }

  Widget _buildTable(BuildContext context) {
    final theme = Theme.of(context);
    final table = DataTable(
      showCheckboxColumn: _selectable,
      sortColumnIndex: _sortColumnIndex,
      sortAscending: sortAscending,
      onSelectAll: _selectable && onSelectAll != null
          ? (value) => onSelectAll!(value ?? false)
          : null,
      headingTextStyle: theme.textTheme.titleSmall,
      columns: [
        for (final c in columns)
          DataColumn(
            label: Text(c.label),
            numeric: c.numeric,
            onSort: c.sortField == null || onSort == null
                ? null
                : (columnIndex, ascending) => onSort!(c.sortField!),
          ),
        if (actions != null) const DataColumn(label: Text('Действия')),
      ],
      rows: [for (final item in items) _buildRow(item, theme)],
    );

    // Двумерная прокрутка: таблица не уезжает за край окна ни по ширине,
    // ни по высоте. minWidth растягивает узкую таблицу на всю ширину.
    return LayoutBuilder(
      builder: (context, constraints) => SingleChildScrollView(
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: ConstrainedBox(
            constraints: BoxConstraints(minWidth: constraints.maxWidth),
            child: table,
          ),
        ),
      ),
    );
  }

  DataRow _buildRow(T item, ThemeData theme) {
    final id = idOf(item);
    final inactive = isInactive?.call(item) ?? false;
    final isSelected = selected.contains(id);
    return DataRow(
      key: ValueKey(id),
      selected: isSelected,
      onSelectChanged: _selectable
          ? (value) {
              if ((value ?? false) != isSelected) onToggleSelect!(id);
            }
          : null,
      color: inactive
          ? WidgetStatePropertyAll(theme.colorScheme.surfaceContainerHighest)
          : null,
      cells: [
        for (final c in columns)
          DataCell(
            _dim(c.build(item), inactive),
            onTap: onOpen == null ? null : () => onOpen!(item),
          ),
        if (actions != null)
          DataCell(Row(mainAxisSize: MainAxisSize.min, children: actions!(item))),
      ],
    );
  }

  // --------------------------------------------------------------- карточки

  Widget _buildCards(BuildContext context) {
    final sortBar = _buildSortBar(context);
    final offset = sortBar == null ? 0 : 1;
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
      itemCount: items.length + offset,
      separatorBuilder: (context, index) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        if (sortBar != null && index == 0) return sortBar;
        return _buildCard(context, items[index - offset]);
      },
    );
  }

  Widget _buildCard(BuildContext context, T item) {
    final theme = Theme.of(context);
    final id = idOf(item);
    final inactive = isInactive?.call(item) ?? false;
    final isSelected = selected.contains(id);
    return Card(
      key: ValueKey(id),
      margin: EdgeInsets.zero,
      color: isSelected
          ? theme.colorScheme.secondaryContainer
          : inactive
              ? theme.colorScheme.surfaceContainerHighest
              : null,
      child: InkWell(
        onTap: onOpen == null ? null : () => onOpen!(item),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, 12, 8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (_selectable)
                Checkbox(
                  value: isSelected,
                  onChanged: (_) => onToggleSelect!(id),
                )
              else
                const SizedBox(width: 12),
              Expanded(
                child: _dim(
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 10),
                      DefaultTextStyle.merge(
                        style: theme.textTheme.titleMedium,
                        child: columns.first.build(item),
                      ),
                      const SizedBox(height: 6),
                      for (final c in columns.skip(1))
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 110,
                                child: Text(
                                  c.label,
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                ),
                              ),
                              Expanded(child: c.build(item)),
                            ],
                          ),
                        ),
                    ],
                  ),
                  inactive,
                ),
              ),
              if (actions != null)
                Column(mainAxisSize: MainAxisSize.min, children: actions!(item)),
            ],
          ),
        ),
      ),
    );
  }

  /// На карточках заголовков нет, поэтому сортировка выбирается из списка.
  Widget? _buildSortBar(BuildContext context) {
    final sortable = columns.where((c) => c.sortField != null).toList();
    if (sortable.isEmpty || onSort == null) return null;
    final current =
        sortable.any((c) => c.sortField == sortField) ? sortField : null;
    return Row(
      children: [
        const Text('Сортировка:'),
        const SizedBox(width: 8),
        DropdownButton<String>(
          value: current,
          hint: const Text('—'),
          items: [
            for (final c in sortable)
              DropdownMenuItem(value: c.sortField, child: Text(c.label)),
          ],
          onChanged: (field) {
            if (field != null && field != sortField) onSort!(field);
          },
        ),
        IconButton(
          tooltip: sortAscending ? 'По возрастанию' : 'По убыванию',
          icon: Icon(sortAscending ? Icons.arrow_upward : Icons.arrow_downward),
          onPressed: current == null ? null : () => onSort!(sortField!),
        ),
      ],
    );
  }

  static Widget _dim(Widget child, bool inactive) =>
      inactive ? Opacity(opacity: 0.6, child: child) : child;
}
